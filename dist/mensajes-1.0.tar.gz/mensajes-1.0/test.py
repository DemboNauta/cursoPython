from mensajes.saludos import *

saludar()

saludo = Saludo()