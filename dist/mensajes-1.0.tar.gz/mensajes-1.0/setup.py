from setuptools import setup

setup(
    name='Mensajes',
    version='1.0',
    description='Un paquete para saludar y despedir',
    author='Edgar Milá Molero',
    author_email='edgar@edgar.com',
    url='www.devthreads.es',
    packages=['mensajes'],
    scripts=['test.py']
)